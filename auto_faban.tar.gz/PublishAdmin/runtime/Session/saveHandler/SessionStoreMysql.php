<?php
/**
 * The Session mysql
 * @author Yi Zhao <zhao5908@gmail.com>
 * @license http://opensource.org/licenses/BSD-3-Clause New BSD License
 * @version svn:$Id: SessionStoreMysql.php 964 2012-08-27 04:02:32Z zhao5908@gmail.com $
 */

/**
 * The Session mysql
 * @author Yi Zhao <zhao5908@gmail.com>
 * @category runtime
 * @package   Lotusphp\Session
 * @subpackage saveHandler
 */
class LtSessionMysql
{
	
}