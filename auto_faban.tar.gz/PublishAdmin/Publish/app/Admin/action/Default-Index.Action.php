<?php
class DefaultIndexAction extends ModuleAction {
	public function __construct() {
		parent::__construct ();
	}
	
	public function execute() {
		/**
		 * @todo Code here ...
		**/
	}
}
