
<legend>权限检查</legend>

    <?php foreach($this->data['permissions'] as $key=>$val){

        echo "<ul class='breadcrumb'><li class='active'>$key..............".(!$val['bool']?"<span class='text-error'>不".$val['type']."</span>":"<span class='text-success'>".$val['type']."</span>")."</li></ul>";

    }?>
