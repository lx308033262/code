<div class="alert alert-dismissable alert-warning">
    <p>操作执行完成，并不一定执行成功，请仔细查看操作执行返回信息，以确认操作是否成功！</p>
</div>
<legend>回滚模块<?php echo $this->data['name'];?></legend>
<div>
    <?php echo $this->data['templateBtn'];?>
</div>