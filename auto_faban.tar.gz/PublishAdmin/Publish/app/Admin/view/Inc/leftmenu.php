<div class="well sidebar-nav">
    <ul class="nav nav-list">
        <li class="nav-header">运维管理菜单项</li>
        <li><a href="{url("Module", "Add")}">新增模块</a></li>
        <li><a href="{url("Module", "List")}">模块管理</a></li>
        <li><a href="{url("Module", "Exclude")}">文件排除</a></li>
        <li><a href="{url("Module", "Config")}">系统配置</a></li>
        <li><a href="{url("Module", "Check")}">权限检查</a></li>

        <!--
         <li><a href="{url("Module", "Update")}">更新模块</a></li>
         <li><a href="{url("Module", "Rollback")}">回滚模块</a></li>
        <li><a href="{url("Module", "Backup")}">备份模块</a></li>
        -->
    </ul>
</div>