
<legend>文件排除配置</legend>
<form class="form-horizontal" method="post">
    <fieldset>

        <div class="control-group">
 同步时需要排除的文件 一行一个文件名称：

        </div>
        <div class="control-group">
                <textarea name="content" class="form-control" rows="8"><?php echo $this->data['excludeContent'];?></textarea>
        </div>

        <div class="form-group">
            <div class="offset2">
                <button type="submit" class="btn btn-primary">提交</button>
            </div>
        </div>
    </fieldset>
</form>