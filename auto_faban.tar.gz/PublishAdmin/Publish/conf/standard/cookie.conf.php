<?php
$config['cookie.secret_key'] = 'ZY)&%$!@$(#*';