#!/usr/bin/python
# -*- coding: utf-8 -*-
#########################
#   Auther:zhanghao     #
#########################

#####本更新程序包括3个文件 
#####update.py 更新脚本 
#####mod.ini 更新服务器及模块 等配置信息
#####exclude.txt 同步时需要排除的文件 一行一个文件名称

#####配置文件中如果是jar包 mod_name必须和jar包名一样
#####本地文件夹名称必须和模块名称一样，可以是文件夹也可以是tar.gz或者zip包


import sys,os,pexpect,fileinput,paramiko,datetime,time
from ConfigParser import ConfigParser
##########变量设置#################
#开始时间（结束后有个结束时间，两者相减即程序运行时间）
starttime=datetime.datetime.now()
#today="2014-5-21-101110"
today=time.strftime("%Y-%-m-%-d-%-H%-M",time.localtime())

#程序及配置文件所在路径
src_dir_prefix="/home/update/"
#模块信息配置文件
mod_file=src_dir_prefix + "mod.ini"
#同步需要排除的文件
exclude_file=src_dir_prefix + "exclude.txt"

#本地主机同步目录(备份目录）
#dst_dir="/home/backup/" + today + "/"
local_backup_dir_prefix="/home/backup/"

#程序上传目录(上传目录不需加日期 每次替换上次上传的版本)
#upload_dir="/home/update/" + today
upload_dir="/home/update/"

#配置文件多IP分隔符
s_field='|'

#读取配置文件
#模块IP/路径/模块类型
#PS:如果有tomcat 还需指定tomcat路径（重启tomcat服务用）
cf=ConfigParser()
cf.read(mod_file)


def helpFunc(a,b,c,d):
    print ""
    print "usage: update.py -m module_name -a action_type"
    print "-l will only print all of the mod_name and exit"
    print "module_name provide module_name to update"
    print ""
    print "action type is update|backup|rollback|full_update|test_update"
    print ""
    print "list mod:"
    print cf.sections()
    sys.exit(3)

def verFunc(a,b,c,d):
    print "Ver 0.0.1"
    sys.exit(3)

#日志文件
log_file=('.logfile')
######## 日志装饰器 #########
#from time import ctime
def log_fun(func):
    def wrappedFunc(*args,**kwargs):
        log_str='[%s] %s([%s],[%s]) executed \n' % (time.ctime(),func.__name__,args,kwargs)
        open(log_file,'a').writelines(log_str)
        #hist_str='%s(%s,%s) \n' % (func.__name__,args,kwargs)
        #open(hist_file,'a').writelines(hist_str)
        return func(*args,**kwargs)
    return wrappedFunc
######## 日志装饰器 #########


from optparse import OptionParser
parser = OptionParser(add_help_option=0)
parser.add_option("-h", "--help", action="callback", callback=helpFunc)
parser.add_option("-v", "--version", action="callback", callback=verFunc)
parser.add_option("-m", "--module", action="store", type="string",dest="mod",default="")
parser.add_option("-a", "--action", action="store", type="string",dest="act",default="")
parser.add_option("-A", "--auto", action="store_true",dest="auto",default=True)
parser.add_option("-V", "--rollback_version", action="store",dest="version",default="")
parser.add_option("-l", "--list", action="store_true", dest="list")

(options, args) = parser.parse_args()
mod_name=options.mod
action=options.act
version=options.version
#print options
#print version
try:
    print auto
except:
    auto=False

#如果指定-l，仅列出模块列表 安全退出
if options.list:
    print cf.sections()
    sys.exit(0)


#如果没有指定模块名或者动作,打印错误并退出 
if mod_name or action:
    pass
else:
    print '''you don't have mod_name and action!\nuse -h get some help'''
    sys.exit()

#如果模块不在模块列表中，打印错误信息并退出
if not cf.has_section(mod_name):
    sys.exit("mod_name %s not in mod_list\nmod_list must in \n %s \n\n see %s get more information" % (mod_name,cf.sections(),mod_file))

#在远程主机上执行命令的函数
@log_fun
def run_command(cmd):
    #print cmd
    client=paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.load_system_host_keys()
    client.connect(hostname=host, port=port,username=user,password=password)
    stdin,stdout,stderr = client.exec_command(cmd)
    print stderr.read()
    print stdout.read()
    client.close()

print starttime

class haixuan():

    def __init__(self,mod_name='',host='',port='',upload_file_prefix='',local_backup_dir='',user='',password='',is_compress=''):
        self.mod_name = mod_name
        self.host = host
        self.user = user
        self.password = password
        self.port = port
        self.is_compress = is_compress
        self.upload_file_prefix = upload_file_prefix
        self.local_backup_dir = local_backup_dir
        #print "upload_dir",upload_dir,"upload_file_prefix",upload_file_prefix,"local_backup_dir",local_backup_dir,"local_backup_dir_prefix",local_backup_dir_prefix,"remote_dst_file",remote_dst_file,"is_compress",is_compress

    @log_fun
    def scp_source_package_to_local(self):
        if cf.has_option(mod_name,'source_host') and cf.has_option(mod_name,'source_path') and cf.has_option(mod_name,'source_user') and cf.has_option(mod_name,'source_password'):
            if cf.has_option(mod_name,'source_port'):
                self.source_port = cf.get(mod_name,'source_port')
            else:
                self.source_port = 22
            self.source_host = cf.get(mod_name,'source_host')
            self.source_path = cf.get(mod_name,'source_path')
            backup_cmd="scp -P %s -r %s@%s:%s %s" % (self.source_port,self.source_user,self.source_host,self.source_path,upload_unzip_dir)
            print backup_cmd
            try:
                outfile=pexpect.run (backup_cmd, events={'(?i)password': self.password+'\n','continue connecting (yes/no)?':'yes\n'},timeout=None)
                print outfile
                print ""
            except Exception as e:
                print e
        else:
            sys.exit("Make sure you define source_host/source_path/source_user/source_password")
                
    @log_fun
    def replace_config(self):
        for file in replace_config.txt:
            mv file+"_online" file
        
    @log_fun
    def deploy_module(self):
        if type == "java":
	    rcmd='ls /usr/local/jdk* > /dev/null 2>&1  && echo 0 || echo 125'
            run_command(rcmd)
            self.deploy_jdk()
            self.deploy_tomcat()
        elif type == "php":
            self.deploy_nginx()
            self.deploy_php()
	else:
	    print "mod_type error"
	    sys.exit()

    @log_fun
    def mv_upload_file_to_backup_dir(self):
        #判断上传目录中是否有压缩包
        #if cf.has_option(mod_name,'is_compress') and cf.get(mod_name,'is_compress') == 'True':
        print self.is_compress
        if self.is_compress == 'True':
            if os.path.exists("%s" % self.upload_file_prefix+".tar.gz") or os.path.exists("%s" % self.upload_file_prefix+".zip"):
        #如果是压缩包先解压
        #复制文件到本地同步目录
                if type == "java":
                    os.path.exists(local_backup_dir) or os.makedirs(local_backup_dir)
                    print "chdir",local_backup_dir
                    os.chdir(local_backup_dir)
                    print "cp %s.tar.gz %s 2>/dev/null||cp %s.zip %s 2>/dev/null"
                    os.system("cp %s.tar.gz %s 2>/dev/null||cp %s.zip %s 2>/dev/null " % (self.upload_file_prefix,local_backup_dir,self.upload_file_prefix,local_backup_dir))
                elif type == "c" or type == "php":
                    os.path.exists(self.local_backup_dir) or os.makedirs(self.local_backup_dir)
                    os.chdir(self.local_backup_dir)
                    os.system("cp %s.tar.gz %s 2>/dev/null||cp %s.zip %s 2>/dev/null " % (self.upload_file_prefix,self.local_backup_dir,self.upload_file_prefix,self.local_backup_dir))
                    print "cp %s.tar.gz %s 2>/dev/null||cp %s.zip %s 2>/dev/null"
                else:
                    print "mod_type error"
                    sys.exit()
                #print os.path.abspath(os.path.curdir)
                os.chdir(local_backup_dir)
                os.system("tar xzf %s.tar.gz 2> /dev/null||unzip %s.zip >/dev/null 2>&1" % (self.mod_name,self.mod_name))
                #print "tar xzf %s.tar.gz 2> /dev/null||unzip %s.zip 2>/dev/null" % (mod_name,mod_name)
                os.system("rm -f %s.tar.gz 2>/dev/null;rm -f %s.zip >/dev/null 2>&1" % (self.mod_name,self.mod_name))
                #print "rm -f %s.tar.gz 2>/dev/null;rm -f %s.zip 2>/dev/null" % (mod_name,mod_name)
                if type == "c":
                    os.system("[ -d %s ] && mv %s/* ./ && rmdir %s" % (self.mod_name,self.mod_name,self.mod_name))
            else:
                print upload_dir + "can't find" + self.mod_name + ".zip or" + self.mod_name + ".tar.gz"
        else:
            #如果没有压缩包 是否有文件夹
            if os.path.exists("%s" %  upload_unzip_dir):
                os.system(cp -a %s %s) % (upload_unzip_dir,self.local_backup_dir)
            #如果都没有 退出
            else:
                print upload_dir + " does't have " + self.mod_name + " directory"
                sys.exit()



    @log_fun
    def stop_program(self):
        #关闭应用
        #print "echo stop start"
        if type == "java":
            self.webapp=cf.get(self.mod_name,"tomcat_path")
            rcmd='''ps aux|grep %s|grep -v grep|awk '{print $2}'|xargs kill -9;rm -rf %s/work/Catalina/''' % (self.webapp,self.webapp)
        elif type == "jar":
            rcmd='''ps aux|grep %s|grep -v grep|awk '{print $2}'|xargs kill -9''' % (self.mod_name)
        elif type == "c":
            self.pname=remote_dst_file.split("/")[-1]
            rcmd='''bash -c "ps -ef|grep -i %s|grep -v grep|awk '{print $2}'|xargs kill -9"'''  % self.pname
        else:
            return 1
        run_command(rcmd)

    @log_fun
    def start_program(self):
        #启动应用
        #self.time=
        if type == "java":
            rcmd='source /etc/profile && %s/bin/startup.sh' % self.webapp
        elif type == "c":
            rcmd='''cd %s &&  find ./bin  -path "*bak" -prune -o  -type f -exec test -x {} \; -a -exec ls {} \;|xargs -I a nohup a''' % remote_dst_file
        elif type == "jar":
            rcmd='''cd %s && nohup java -jar `ls -rt *.jar|tail -1` >/dev/null 2>&1 &''' % remote_dst_file
        else:
            return 1
        run_command(rcmd)

    @log_fun
    def check_status(self):
        #检测应用启动后是否报错
        if type == "java":
            #rcmd='grep -e -i -A500 '%s' %s/logs/catalina.out|grep -e 'Exception|error' %s/logs/catalina.out ' % (self.time,self.webapp)
            rcmd='''tail -n 2000 '%s' %s/logs/catalina.out|grep -i -A50 'Exception|error' %s/logs/catalina.out ''' % (self.webapp,self.webapp)
        elif type == "jar":
            rcmd='''tail -n 2000 '%s' %s/logs/err|grep -i -A50 'Exception|error' %s/logs/err ''' % (self.webapp,self.webapp)
        else:
            return 1
        run_command(rcmd)

    @log_fun
    def update(self):
        #同步更新到远程服务器
        if auto:
            self.scp_source_package_to_local()
        self.mv_upload_file_to_backup_dir()
        self.stop_program()
        rcmd="rsync -e 'ssh -p %s' -avz --exclude-from=%s %s %s@%s:%s" % (self.port,exclude_file,local_backup_file_prefix,self.user,self.host,remote_dst_file+"/")
        print rcmd
        outfile=pexpect.run (rcmd, events={'(?i)password': self.password+'\n','continue connecting (yes/no)?':'yes\n'},timeout=None)
        print outfile
        print ""
        self.start_program()

    @log_fun
    def backup(self):
        #备份操作
        print "backup start"
        os.path.exists(local_backup_file_prefix) or os.makedirs(local_backup_file_prefix)
        backup_cmd="scp -P %s -r %s@%s:%s %s" % (self.port,self.user,self.host,remote_dst_file,local_backup_file_prefix)
        print backup_cmd
        outfile=pexpect.run (backup_cmd, events={'(?i)password': self.password+'\n','continue connecting (yes/no)?':'yes\n'},timeout=None)
        print outfile
        print ""
        print "%s backup successful!" % self.mod_name

    @log_fun
    def rollback(self,version=""):
        #回滚
        #如果没有指定版本，找出时间最近的一次版本进行回滚
        #print "start rollback"
        if not version:
            local_backup_mod_dir=local_backup_dir_prefix + mod_name + "/"
            cmd='''ls -rt %s|tail -1''' % local_backup_mod_dir
            version=os.popen(cmd).read().rstrip()
        #回滚目录
        self.back_dir=local_backup_dir_prefix + mod_name + "/" + version + "/"
        rcmd="rsync -e 'ssh -p %s' -avz --delete --exclude-from=%s %s %s@%s:%s" % (self.port,exclude_file,self.back_dir,self.user,self.host,remote_dst_file+"/")
        print rcmd
        sys.exit()
        outfile=pexpect.run (rcmd, events={'(?i)password': self.password+'\n','continue connecting (yes/no)?':'yes\n'},timeout=None)
        print outfile
        print ""

    @log_fun
    def full_update(self):
        #全量更新
        if auto:
            self.scp_source_package_to_local()
        self.mv_upload_file_to_backup_dir()
        self.stop_program()
        self.exclude_file=""
        rcmd="rsync -e 'ssh -p %s' -avz --exclude-from=%s %s %s@%s:%s" % (self.port,self.exclude_file,local_backup_file_prefix,self.user,self.host,remote_dst_file+"/")
        print rcmd
        outfile=pexpect.run (rcmd, events={'(?i)password': self.password+'\n','continue connecting (yes/no)?':'yes\n'},timeout=None)
        print outfile
        print ""
        self.start_program()


    @log_fun
    def test_update(self):
        if auto:
            self.scp_source_package_to_local()
        self.mv_upload_file_to_backup_dir()
        rcmd="rsync -e 'ssh -p %s' -avz -n --exclude-from=%s %s %s@%s:%s" % (self.port,exclude_file,local_backup_file_prefix,self.user,self.host,remote_dst_file+"/")
        print rcmd
        outfile=pexpect.run (rcmd, events={'(?i)password': self.password+'\n','continue connecting (yes/no)?':'yes\n'},timeout=None)
        print outfile
        print ""

        

host_list=cf.get(mod_name,'ip').split(s_field)
for host in host_list:
    #获取给定模块的主机IP、路径和程序类型
    #获取文件路径和cp路径必须获取模块名后才能确定 所以没写在上面的变量设定中
    #print host
    host_index=host_list.index(host)
    try:
        remote_dst_file=cf.get(mod_name,"path")
        type=cf.get(mod_name,"type")
        #如果有端口/用户/密码选项则读取，没有则默认为37815/root/123456
        #如果有多个IP/端口/用户/密码 则根据list中的index查找
        if cf.has_option(mod_name,'user') and len(host_list)>host_index:
            user_list=cf.get(mod_name,'user').split(s_field)
            user=user_list[host_index]
        elif cf.has_option(mod_name,'user'):
            user=cf.get(mod_name,'user')
        else:
            user='root'
        if cf.has_option(mod_name,'password') and len(host_list)>host_index:
            password_list=cf.get(mod_name,'password').split(s_field)
            password=password_list[host_index]
        elif cf.has_option(mod_name,'password'):
            password=cf.get(mod_name,'password')
        else:
            password='123456'
        if cf.has_option(mod_name,'port') and len(host_list)>host_index:
            port_list=cf.get(mod_name,'port').split(s_field)
            port=port_list[host_index]
        elif cf.has_option(mod_name,'port'):
            port=cf.get(mod_name,'port')
        else:
            port=37815
        #判断上传文件是否是压缩包
        if cf.has_option(mod_name,'is_compress') and cf.get(mod_name,'is_compress') == 'True':
            is_compress='True'
        else:
            is_compress='False'
        #上传文件名称前缀
        upload_file_prefix=upload_dir + "/" + mod_name
        #解压文件夹
        upload_unzip_dir=upload_dir + "/" + mod_name + "/"
        #同步文件夹名称
        #本地备份文件夹名称（本地和远程模块同步文件夹名称）
        local_backup_dir=local_backup_dir_prefix + mod_name + "/" + today + "/"
        local_backup_file_prefix=local_backup_dir_prefix + mod_name + "/" + today + "/" + mod_name
        #print upload_dir,upload_file_prefix,upload_unzip_dir,local_backup_dir_prefix,local_backup_dir,is_compress
        #print user,password,port
    except Exception as e:
        print e
        sys.exit("mod_name error!")

    t=haixuan(mod_name=mod_name,host=host,port=port,upload_file_prefix=upload_file_prefix,local_backup_dir=local_backup_dir,user=user,password=password,is_compress=is_compress)
    try:
        eval("t.%s()" % action)
    except Exception as e:
        print e
        print '''this instance doesn't have this method name'''



endtime=datetime.datetime.now()
print "this program consumed %s seconds " % (endtime - starttime)
